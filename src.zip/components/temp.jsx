import React from "react";

function Temp(){
    return <h1 className="text-2xl">Hello this is temp</h1>
}
export default Temp;